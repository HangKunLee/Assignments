touch file3.txt
git add file3.txt
git commit -m "Add file3.txt"
