mkdir dir1
touch dir1/file2
git add dir1
