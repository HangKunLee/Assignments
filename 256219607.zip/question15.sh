git clone https://github.com/ian-knight-uofa/git-practice-01.git
cd git-practice-01
git fetch origin
git checkout main
git merge origin/branch1
git add .
git commit -m "Resolved merge conflicts between main and branch1"
shihhsihihsid
