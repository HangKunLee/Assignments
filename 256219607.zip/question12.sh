git checkout branch2
git stash pop

git add file4
git commit -m "Modify file4 in branch2"

