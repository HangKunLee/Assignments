mkdir dir1
touch dir1/file2
git add .
git commit -m "add dir1"

