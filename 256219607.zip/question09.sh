git branch branch1
git checkout branch1
touch file3
git add file3
git commit -m "Add file3 in branch1"
