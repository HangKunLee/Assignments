git checkout -b assignment-branch
rm question03.sh question04.sh question05.sh question07.sh question08.sh question09.sh question10.sh question11.sh question12.sh
git add .
touch file13.txt
git add file13.txt
git commit -m "Remove old .sh files and add file13.txt"

