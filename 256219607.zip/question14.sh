git clone https://github.com/ian-knight-uofa/git-practice-04.git
cd git-practice-04
chmod +x question14.sh
git fetch origin
git checkout update1
git branch

