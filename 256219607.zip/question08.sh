mkdir dir2
mv *.txt dir2
git add .
git commit -m "Move all text files to dir2"

