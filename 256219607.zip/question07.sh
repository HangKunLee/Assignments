git add *.py
git commit -m "Add and commit all Python files"
